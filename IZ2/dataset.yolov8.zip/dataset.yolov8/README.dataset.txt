# IZ2_mod > 2025-11-13 1:45pm
https://universe.roboflow.com/darya-88jqg/iz2_mod-m0ngg

Provided by a Roboflow user
License: CC BY 4.0

